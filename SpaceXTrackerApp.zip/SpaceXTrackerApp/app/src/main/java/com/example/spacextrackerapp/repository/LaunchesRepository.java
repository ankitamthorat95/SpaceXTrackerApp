package com.example.spacextrackerapp.repository;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import com.example.spacextrackerapp.database.AppDatabase;
import com.example.spacextrackerapp.database.dao.LaunchesDao;
import com.example.spacextrackerapp.model.FlightItemDetails;

import java.util.List;

public class LaunchesRepository {
    public LaunchesDao launchesDao;
    public LiveData<List<FlightItemDetails>> getAllLaunches;
    private AppDatabase database;

    public LaunchesRepository(Application application){
        database=AppDatabase.getInstance(application);
        launchesDao=database.launchesDao();
        getAllLaunches=launchesDao.getAllLaunches();

    }



    public void insert(List<FlightItemDetails> cats){
        new InsertAsyncTask(launchesDao).execute(cats);

    }

    public LiveData<List<FlightItemDetails>> getAllLaunches(){
        return getAllLaunches;
    }
    private static class InsertAsyncTask extends AsyncTask<List<FlightItemDetails>,Void,Void> {
        private LaunchesDao launchesDao;

        public InsertAsyncTask(LaunchesDao launchesDao)
        {
            this.launchesDao=launchesDao;
        }
        @Override
        protected Void doInBackground(List<FlightItemDetails>... lists) {
            launchesDao.insert(lists[0]);
            return null;
        }
    }

}
