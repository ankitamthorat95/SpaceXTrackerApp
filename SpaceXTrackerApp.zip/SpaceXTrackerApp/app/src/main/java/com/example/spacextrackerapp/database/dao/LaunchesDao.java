package com.example.spacextrackerapp.database.dao;


import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;

import androidx.lifecycle.LiveData;

import com.example.spacextrackerapp.model.FlightItemDetails;

import java.util.List;

@Dao
public interface LaunchesDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(List<FlightItemDetails> cats);

    @Query("SELECT DISTINCT * FROM launches")
    LiveData<List<FlightItemDetails>> getAllLaunches();

    @Query("DELETE FROM launches")
    void deleteAll();
}
