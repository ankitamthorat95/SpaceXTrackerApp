package com.example.spacextrackerapp.utils;

public class Constants {
       String BASE_URL="https://raw.githubusercontent.com";

}
