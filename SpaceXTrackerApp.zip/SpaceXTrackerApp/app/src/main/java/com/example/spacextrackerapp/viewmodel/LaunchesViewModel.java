package com.example.spacextrackerapp.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.spacextrackerapp.model.FlightItemDetails;
import com.example.spacextrackerapp.repository.LaunchesRepository;

import java.util.List;

public class LaunchesViewModel extends AndroidViewModel {
    private LaunchesRepository repository;
    public LiveData<List<FlightItemDetails>> getAllLaunches;

    public LaunchesViewModel(@NonNull Application application) {
        super(application);
        repository=new LaunchesRepository(application);
        getAllLaunches=repository.getAllLaunches();
    }

    public void insert(List<FlightItemDetails> launches){
        repository.insert(launches);
    }

    public LiveData<List<FlightItemDetails>> getAllLaunches()
    {
        return getAllLaunches;
    }
}
